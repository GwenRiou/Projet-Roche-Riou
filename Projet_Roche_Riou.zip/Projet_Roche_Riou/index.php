<?php

header('Location: app/router/router2.php?action=true');

?>

