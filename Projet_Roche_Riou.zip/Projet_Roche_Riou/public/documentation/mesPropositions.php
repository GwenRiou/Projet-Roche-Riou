<ul>mes proposition
    <li>On pourrais affiche le nombres de vin produit par un producteur et leur quantité.</li>
</ul>
    
    
    
    
    